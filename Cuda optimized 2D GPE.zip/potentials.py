"""
potentials.py — external trapping potentials V(x, y) on the GPU.

PotentialBuilder is stateless between calls: it holds only the pre-computed
coordinate grids (X, Y, _r) shared with the physics engine.
All returned arrays are CuPy float32.
"""
from __future__ import annotations

import math

import cupy as cp


class PotentialBuilder:
    """
    Compute V(x, y) for each supported trap geometry.

    Slider parameters (v0, w) are passed at call time, so no internal mutable
    state is needed — only the constant coordinate grids live on the instance.
    """

    def __init__(self, X: cp.ndarray, Y: cp.ndarray) -> None:
        self.X  = X
        self.Y  = Y
        # Radial distance is identical for every potential; compute once.
        self._r = cp.sqrt(X**2 + Y**2)

    def build(self, pot_type: str, v0: float, w: float) -> cp.ndarray:
        """
        Return the external potential as a float32 CuPy array.

        Parameters
        ----------
        pot_type : one of POTENTIAL_TYPES from config.py.
        v0       : overall strength (raw integer slider value; no scaling).
        w        : width / radius (slider value already divided by W_SLIDER_SCALE).
        """
        X, Y, r = self.X, self.Y, self._r
        eps = 1e-5   # small offset to prevent division by zero

        if pot_type == "Harmonic":
            # Isotropic harmonic trap — the standard BEC geometry.
            # Factor of 1/10 sets the trap frequency scale relative to the grid.
            V = v0 * ((X / 10.0)**2 + (Y / 10.0)**2)

        elif pot_type == "Ring":
            # Toroidal trap: a harmonic trough centred at radius R = 2w.
            V = v0 * (r - 2.0 * w)**2

        elif pot_type == "Lattice":
            # Standing-wave optical lattice with a Gaussian envelope (σ = 8).
            # The envelope prevents a hard step at the domain boundary, which
            # would otherwise introduce Gibbs ringing in the FFT.
            envelope = cp.exp(-(r**2) / 64.0)
            V = v0 * (cp.sin(math.pi * X / w)**2
                      + cp.sin(math.pi * Y / w)**2) * envelope

        elif pot_type == "Box":
            # Flat-bottom box trap with a smooth sigmoid wall of width ~0.2w.
            # A hard step function would cause severe FFT ringing artefacts.
            V = v0 / (1.0 + cp.exp(-5.0 * (r - 1.5 * w)))

        elif pot_type == "Double Well":
            # Quartic double-well along x, harmonic confinement along y.
            # The two minima sit at x ≈ ±w.
            V = v0 * ((X**2 / (w**2 + eps) - 1.0)**2 + (Y / 5.0)**2)

        elif pot_type == "Gaussian Pillar":
            # Localised repulsive (v0 > 0) or attractive (v0 < 0) laser spot.
            V = v0 * cp.exp(-(r**2) / (w**2 + eps))

        else:  # "None" or any unrecognised string
            V = cp.zeros_like(X)

        return V.astype(cp.float32)
