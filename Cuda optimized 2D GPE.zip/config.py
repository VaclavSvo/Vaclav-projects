"""
config.py — all tunable constants in one place.

Edit this file to change grid size, time-step, UI dimensions, or GIF settings.
Nothing here imports from the rest of the project.
"""

# ── Physics ───────────────────────────────────────────────────────────────────
GRID_SIZE       = 512    # N×N grid; must be a power of 2 for optimal cuFFT.
                          # 2048 works on a 16 GB GPU; reduce STEPS_PER_FRAME
                          # proportionally to keep the UI responsive.
DOMAIN_SIZE     = 21.0   # Physical box edge length; x, y ∈ [−L/2, L/2].
TIME_STEP       = 0.001  # Δt for the split-step Fourier integrator.
STEPS_PER_FRAME = 30     # Physics sub-steps executed between each UI frame.
INTERACTION     = 1.0    # Gross-Pitaevskii nonlinear coupling constant g.

# ── Potential menu ────────────────────────────────────────────────────────────
POTENTIAL_TYPES = [
    "None", "Harmonic", "Ring", "Lattice",
    "Box", "Double Well", "Gaussian Pillar",
]
V0_MAX          = 500    # Upper limit of the V₀ (strength) slider.
W_SLIDER_SCALE  = 10     # Slider integer value ÷ scale → float w.

# ── Window ────────────────────────────────────────────────────────────────────
WINDOW_WIDTH    = 1300
WINDOW_HEIGHT   = 700
TIMER_MS        = 16     # Qt animation timer interval (≈ 60 fps).

# ── Display down-sampling ─────────────────────────────────────────────────────
# At large grid sizes the GPU→CPU PCIe transfer is the bottleneck.
# The simulation always runs at full GRID_SIZE resolution; only the data
# sent to pyqtgraph is strided down to ≤ DISPLAY_MAX_PX × DISPLAY_MAX_PX.
DISPLAY_MAX_PX  = 512

# ── GIF export ────────────────────────────────────────────────────────────────
GIF_FPS     = 30          # Target playback frame-rate of the output GIF.
                           # GIF delay is stored in centiseconds; 30 fps → 3 cs.
GIF_DPI     = 90           # Matplotlib raster DPI. Lower = faster rendering.
GIF_FIGSIZE = (12.0, 5.0)  # Figure size in inches (width, height).
