"""
recorder.py — scientific GIF capture and export.

Architecture
------------
_Frame         Dataclass holding one captured display snapshot (density +
               phase + colour-scale bound).  Stored as plain NumPy arrays so
               no GPU memory is held after capture.

_Renderer      Owns a single persistent Matplotlib figure.  Only the image
               data and the suptitle are updated per frame; axes, colorbars,
               and labels are built once.  Renders directly from the Agg
               framebuffer (no PNG encode/decode round-trip).

_RenderThread  QThread that renders all collected frames and writes the GIF.
               Communicates with the main thread exclusively through Qt
               signals — no direct cross-thread widget calls.

GifRecorder    QObject subclass that owns the frame buffer and the render
               thread.  Exposes a save_finished signal the main window
               connects to at start-up.

RecordDialog   Simple modal QDialog to ask the user for a recording duration.

GIF aesthetic (dark scientific theme)
--------------------------------------
  • Background  #0d0d0d
  • Density      'inferno' colormap, colorbar labelled |ψ|²
  • Phase        'hsv' cyclic colormap, ticks at −π, −π/2, 0, +π/2, +π
  • Suptitle     potential type · g value · grid size N · frame counter
"""
from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np

import matplotlib
matplotlib.use('Agg')          # must be set before importing pyplot
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from PIL import Image

from PyQt6 import QtCore, QtWidgets

from config import GIF_FPS, GIF_DPI, GIF_FIGSIZE

# ── Theme constants ────────────────────────────────────────────────────────────
_BG         = '#0d0d0d'
_FG         = '#dedede'
_SPINE_CLR  = '#3a3a3a'
_GRID_ALPHA = 0.12


# ── Frame data ─────────────────────────────────────────────────────────────────

@dataclass
class _Frame:
    dens         : np.ndarray   # probability density |ψ|², float32
    phase        : np.ndarray   # arg(ψ), float32; NaN where density is negligible
    contrast_high: float        # upper bound of the density colour scale


# ── Persistent Matplotlib renderer ────────────────────────────────────────────

class _Renderer:
    """
    Renders GPE arrays into PIL Images using a single reused Matplotlib figure.

    On the first call, axes, colorbars, and labels are built and tight_layout
    is called once.  On every subsequent call only image data and the suptitle
    are updated, so the layout computation is never repeated.

    Pixel data is read directly from the Agg framebuffer via buffer_rgba()
    — no PNG compression or BytesIO buffering.
    """

    def __init__(self, sim_params: dict) -> None:
        self._p     = sim_params
        self._ready = False

        self._fig, (self._ax1, self._ax2) = plt.subplots(
            1, 2,
            figsize=GIF_FIGSIZE,
            facecolor=_BG,
            gridspec_kw={'wspace': 0.42},
        )
        self._fig.patch.set_facecolor(_BG)

    # ── One-time setup (called on first frame) ────────────────────────────────

    def _setup(self, frame: _Frame) -> None:
        ax1, ax2 = self._ax1, self._ax2

        # Density panel
        self._im1 = ax1.imshow(
            frame.dens,
            origin='lower',
            cmap='inferno',
            norm=mcolors.Normalize(vmin=0.0, vmax=frame.contrast_high),
            interpolation='bilinear',
            aspect='equal',
        )
        cb1 = self._fig.colorbar(self._im1, ax=ax1, fraction=0.046, pad=0.04)
        cb1.set_label(r'$|\psi|^2$', color=_FG, fontsize=11)
        self._style_colorbar(cb1)
        self._style_ax(ax1, r'Density  $|\psi|^2$')

        # Phase panel
        self._im2 = ax2.imshow(
            np.ma.masked_invalid(frame.phase),
            origin='lower',
            cmap='hsv',
            norm=mcolors.Normalize(vmin=-np.pi, vmax=np.pi),
            interpolation='bilinear',
            aspect='equal',
        )
        cb2 = self._fig.colorbar(
            self._im2, ax=ax2, fraction=0.046, pad=0.04,
            ticks=[-np.pi, -np.pi / 2, 0.0, np.pi / 2, np.pi],
        )
        cb2.ax.set_yticklabels(
            [r'$-\pi$', r'$-\pi/2$', r'$0$', r'$+\pi/2$', r'$+\pi$'],
            fontsize=9, color=_FG,
        )
        cb2.set_label(r'$\arg(\psi)$', color=_FG, fontsize=11)
        self._style_colorbar(cb2)
        self._style_ax(ax2, r'Phase  $\arg(\psi)$')

        self._sup = self._fig.suptitle('', color=_FG, fontsize=10, y=1.012)

        # Compute the layout once; all subsequent canvas.draw() calls reuse it.
        self._fig.tight_layout()
        self._ready = True

    def _style_ax(self, ax: plt.Axes, title: str) -> None:
        ax.set_facecolor(_BG)
        ax.set_title(title, color=_FG, fontsize=13, pad=7)
        ax.set_xlabel('x', color=_FG, fontsize=10)
        ax.set_ylabel('y', color=_FG, fontsize=10)
        ax.tick_params(colors=_FG, labelsize=8)
        for spine in ax.spines.values():
            spine.set_edgecolor(_SPINE_CLR)
        ax.grid(True, color='#ffffff', alpha=_GRID_ALPHA, linewidth=0.4)

    def _style_colorbar(self, cb) -> None:
        cb.ax.yaxis.set_tick_params(color=_FG, labelsize=8)
        plt.setp(cb.ax.yaxis.get_ticklabels(), color=_FG)
        cb.outline.set_edgecolor(_SPINE_CLR)

    # ── Per-frame render ───────────────────────────────────────────────────────

    def render(self, frame: _Frame, idx: int, total: int) -> Image.Image:
        """
        Update image data in-place, redraw, and return a PIL Image.

        Uses canvas.buffer_rgba() to read raw pixels from the Agg renderer
        — roughly 5–10× faster than savefig() to a BytesIO buffer because
        there is no PNG compression or decompression step.
        """
        if not self._ready:
            self._setup(frame)

        # Update density: set_clim updates the normalization limits in-place
        # without allocating a new Normalize object.
        self._im1.set_data(frame.dens)
        self._im1.set_clim(vmin=0.0, vmax=frame.contrast_high)

        # Phase norm is fixed at (−π, π); only image data needs updating.
        self._im2.set_data(np.ma.masked_invalid(frame.phase))

        self._sup.set_text(
            f"2D GPE Simulation  ·  {self._p.get('potential', 'None')} trap"
            f"  ·  g = {self._p.get('g', 0.0):.1f}"
            f"  ·  N = {self._p.get('N', '?')}"
            f"  ·  frame {idx + 1} / {total}"
        )

        # Draw directly into the Agg framebuffer and read raw RGBA pixels.
        self._fig.canvas.draw()
        w, h  = self._fig.canvas.get_width_height()
        buf   = self._fig.canvas.buffer_rgba()          # memoryview, uint8 RGBA
        return Image.frombuffer('RGBA', (w, h), buf, 'raw', 'RGBA', 0, 1)

    def close(self) -> None:
        plt.close(self._fig)


# ── Background render thread ───────────────────────────────────────────────────

class _RenderThread(QtCore.QThread):
    """
    Renders all captured frames and writes the GIF on a worker thread.

    Communicates only through Qt signals so no widget is ever touched from
    outside the main thread.
    """

    progress_changed = QtCore.pyqtSignal(int)   # 0–100 percent
    save_finished    = QtCore.pyqtSignal(str)   # absolute output path

    def __init__(
        self,
        frames  : list[_Frame],
        params  : dict,
        filepath: str,
        parent  : QtCore.QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._frames   = frames
        self._params   = params
        self._filepath = filepath

    def run(self) -> None:
        renderer   = _Renderer(self._params)
        pil_frames : list[Image.Image] = []
        n = len(self._frames)

        for i, frame in enumerate(self._frames):
            rgba = renderer.render(frame, i, n)
            # GIF requires an 8-bit palette image.  FASTOCTREE is substantially
            # faster than MEDIANCUT and produces comparable quality for the
            # smooth scientific colormaps used here.
            pil_frames.append(
                rgba.convert('RGB').quantize(
                    colors=256, method=Image.Quantize.FASTOCTREE
                )
            )
            self.progress_changed.emit(int(100 * (i + 1) / n))

        renderer.close()

        if pil_frames:
            pil_frames[0].save(
                self._filepath,
                save_all=True,
                append_images=pil_frames[1:],
                loop=0,
                duration=int(1000 / GIF_FPS),  # per-frame delay in milliseconds
                optimize=False,                 # optimize=True is much slower
            )

        self.save_finished.emit(self._filepath)


# ── Public recorder API ────────────────────────────────────────────────────────

class GifRecorder(QtCore.QObject):
    """
    Time-gated frame collector that owns the render thread.

    Inherits QObject so it can expose save_finished as a proper Qt signal,
    which guarantees delivery on the main thread regardless of which thread
    the render worker calls emit() from.

    Typical usage
    -------------
    # At startup:
    recorder.save_finished.connect(on_gif_saved_slot)

    # To start recording:
    recorder.start(duration_s, sim_params)

    # Each display tick:
    done = recorder.try_add_frame(dens, phase, contrast_high)
    if done:
        recorder.begin_save(parent_widget, filepath)
    """

    # Emitted on the main thread once the GIF file has been written.
    save_finished = QtCore.pyqtSignal()

    def __init__(self, parent: QtCore.QObject | None = None) -> None:
        super().__init__(parent)
        self._frames     : list[_Frame]           = []
        self._recording  : bool                   = False
        self._max_frames : int                     = 0
        self._sim_params : dict                    = {}
        self._last_t     : float                   = 0.0
        self._interval   : float                   = 1.0 / GIF_FPS
        self._thread     : _RenderThread | None   = None

    # ── Properties ─────────────────────────────────────────────────────────────

    @property
    def is_recording(self) -> bool:
        return self._recording

    @property
    def frame_progress(self) -> tuple[int, int]:
        """(frames captured so far, total target)"""
        return len(self._frames), self._max_frames

    # ── Recording lifecycle ────────────────────────────────────────────────────

    def start(self, duration_s: float, sim_params: dict) -> None:
        """Begin a new recording session, discarding any previous buffer."""
        self._frames.clear()
        self._max_frames = max(1, round(duration_s * GIF_FPS))
        self._sim_params = dict(sim_params)
        self._recording  = True
        # Subtract one interval so the very first try_add_frame call captures.
        self._last_t     = time.monotonic() - self._interval

    def try_add_frame(
        self,
        dens         : np.ndarray,
        phase        : np.ndarray,
        contrast_high: float,
    ) -> bool:
        """
        Conditionally capture one frame, gated to GIF_FPS.

        Returns True when the frame buffer is full (recording is complete).
        """
        if not self._recording:
            return False

        now = time.monotonic()
        if now - self._last_t < self._interval:
            return False

        self._last_t = now
        self._frames.append(_Frame(dens.copy(), phase.copy(), contrast_high))

        if len(self._frames) >= self._max_frames:
            self._recording = False
            return True

        return False

    def begin_save(self, parent: QtWidgets.QWidget, filepath: str) -> None:
        """
        Spawn a background render thread and show a progress dialog.

        The save_finished signal is emitted on the main thread when the GIF
        file has been fully written — connect to it in the caller's __init__.
        """
        frames = list(self._frames)
        params = dict(self._sim_params)
        self._frames.clear()

        prog = QtWidgets.QProgressDialog(
            "Rendering GIF frames…", None, 0, 100, parent,
        )
        prog.setWindowTitle("Saving GIF")
        prog.setWindowModality(QtCore.Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(0)
        prog.setValue(0)
        prog.show()

        self._thread = _RenderThread(frames, params, filepath, parent=self)
        self._thread.progress_changed.connect(prog.setValue)
        self._thread.save_finished.connect(prog.close)
        self._thread.save_finished.connect(
            lambda p: QtWidgets.QMessageBox.information(
                parent, "GIF Saved",
                f"Simulation GIF saved:\n\n{p}",
            )
        )
        # Re-emit as our own (parameterless) signal for the main window to act on.
        self._thread.save_finished.connect(lambda _: self.save_finished.emit())
        self._thread.start()


# ── Duration dialog ────────────────────────────────────────────────────────────

class RecordDialog(QtWidgets.QDialog):
    """Ask the user how long the GIF recording should be."""

    def __init__(self, parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Record GIF")
        self.setFixedWidth(300)

        layout = QtWidgets.QVBoxLayout(self)

        layout.addWidget(QtWidgets.QLabel("Duration (seconds):"))

        self._spin = QtWidgets.QDoubleSpinBox()
        self._spin.setRange(1.0, 300.0)
        self._spin.setValue(5.0)
        self._spin.setSingleStep(1.0)
        self._spin.setDecimals(1)
        layout.addWidget(self._spin)

        self._info = QtWidgets.QLabel()
        self._info.setStyleSheet("color: #666; font-size: 10px;")
        self._update_info(5.0)
        self._spin.valueChanged.connect(self._update_info)
        layout.addWidget(self._info)

        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButton.Ok
            | QtWidgets.QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _update_info(self, v: float) -> None:
        n = round(v * GIF_FPS)
        self._info.setText(f"≈ {n} frames at {GIF_FPS} fps")

    @property
    def duration(self) -> float:
        return self._spin.value()
