"""
main.py — application window and entry point.

GPEWindow wires together:
  physics     (GPEPhysics)       GPU split-step Fourier simulation
  pot_builder (PotentialBuilder)  V(x, y) computation on the GPU
  recorder    (GifRecorder)       frame capture + GIF export

UI layout
---------
Left panel (stretch 1):
  Start / Pause / Reset   — simulation control
  Save GIF                — opens RecordDialog, then a file picker
  Tab "System"            — mode, temperature, potential type/V₀/w, g
  Tab "Wavepackets"       — two independent Gaussian wavepackets
  Status label

Right panel (stretch 4):
  pyqtgraph GraphicsLayoutWidget
    col 0 — Density  |ψ|²  (inferno colormap)
    col 1 — Phase    arg(ψ) (cyclic colormap)

Performance notes
-----------------
• The potential is recomputed only when a relevant slider changes (dirty flag).
• GPU arrays are sub-sampled to ≤ DISPLAY_MAX_PX before the PCIe transfer.
• Physics and display always run at full GRID_SIZE resolution.
• For 2048² grids, reduce STEPS_PER_FRAME in config.py (try 5–10) to keep
  the UI responsive; the physics quality is unaffected.
"""
from __future__ import annotations

import sys
from collections.abc import Callable

import numpy as np
import pyqtgraph as pg
from PyQt6 import QtCore, QtGui, QtWidgets

try:
    import cupy as cp
except ImportError:
    print("CuPy not found.  Install cupy-cudaXXX matching your CUDA version.")
    sys.exit(1)

from config import (
    GRID_SIZE, INTERACTION,
    POTENTIAL_TYPES, V0_MAX, W_SLIDER_SCALE,
    WINDOW_WIDTH, WINDOW_HEIGHT, TIMER_MS,
)
from physics    import GPEPhysics
from potentials import PotentialBuilder
from recorder   import GifRecorder, RecordDialog

# Row-major image order avoids a transpose inside pyqtgraph on every frame.
pg.setConfigOption('imageAxisOrder', 'row-major')

# ── Shared stylesheet tokens ──────────────────────────────────────────────────

_SLIDER_CSS = (
    "QSlider::groove:horizontal {"
    "  height: 5px; background: #cccccc; border-radius: 2px; }"
    "QSlider::handle:horizontal {"
    "  width: 14px; margin: -5px 0;"
    "  background: #007bb5; border-radius: 7px; }"
)
# Slightly smaller handle for the denser wavepacket tab.
_SLIDER_SM_CSS = _SLIDER_CSS.replace('14px', '12px').replace('-5px', '-4px')

_COMBO_CSS = (
    "QComboBox { background: #fff; color: #222; padding: 6px;"
    "  border: 1px solid #ccc; border-radius: 3px; }"
)
_TAB_CSS = (
    "QTabBar::tab { background: #e0e0e0; color: #333; padding: 8px;"
    "  border: 1px solid #ccc; border-bottom: none;"
    "  border-top-left-radius: 4px; border-top-right-radius: 4px; }"
    "QTabBar::tab:selected { background: #fff; font-weight: bold; color: #111; }"
    "QTabWidget::pane { border: 1px solid #ccc; background: #fff; }"
)
_GROUP_CSS = (
    "QGroupBox { border: 1px solid #ccc; margin-top: 10px; }"
    "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 3px; }"
)
_VAL_CSS  = "color: #006b9c; font-weight: bold; font-size: 11px;"
_BTN_CSS  = "padding: 8px; border-radius: 4px; font-weight: bold; border: none; color: white;"


# ── Widget helpers ────────────────────────────────────────────────────────────

def _btn(text: str, colour: str) -> QtWidgets.QPushButton:
    b = QtWidgets.QPushButton(text)
    b.setStyleSheet(f"background-color: {colour}; {_BTN_CSS}")
    return b


def _labeled_slider(
    layout : QtWidgets.QLayout,
    heading: str,
    lo     : int,
    hi     : int,
    default: int,
    fmt    : Callable[[int], str],
    css    : str = _SLIDER_CSS,
) -> tuple[QtWidgets.QSlider, QtWidgets.QLabel]:
    """
    Add a heading label, a horizontal QSlider, and a value label to *layout*.

    Returns (slider, value_label).  The value label is updated automatically
    on every slider change via the connected lambda.
    """
    layout.addWidget(QtWidgets.QLabel(heading))

    sl = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
    sl.setRange(lo, hi)
    sl.setValue(default)
    sl.setStyleSheet(css)
    layout.addWidget(sl)

    val_lbl = QtWidgets.QLabel(fmt(default))
    val_lbl.setStyleSheet(_VAL_CSS)
    layout.addWidget(val_lbl)

    sl.valueChanged.connect(lambda v: val_lbl.setText(fmt(v)))
    return sl, val_lbl


# ── Main window ───────────────────────────────────────────────────────────────

class GPEWindow(QtWidgets.QMainWindow):
    """
    Top-level application window.  Owns all three subsystems and the Qt timer.
    """

    def __init__(self) -> None:
        super().__init__()
        print(f"GPE Solver  |  Engine: CuPy  |  Grid: {GRID_SIZE}²")

        # ── Subsystems ────────────────────────────────────────────────────────
        self.physics     = GPEPhysics()
        self.pot_builder = PotentialBuilder(self.physics.X, self.physics.Y)
        self.recorder    = GifRecorder(parent=self)

        # ── Application state ─────────────────────────────────────────────────
        self.is_running       : bool = False
        self._potential_dirty : bool = True   # recompute V before next step
        self._pending_gif_path: str  = ''

        # Wavepacket parameters — kept in sync with the sliders.
        self._wp: dict[str, dict] = {
            'wp1': dict(x=-6.0, y=1.5,  vx=15.0,  vy=0.0, w=2.5),
            'wp2': dict(x= 6.0, y=-1.5, vx=-15.0, vy=0.0, w=2.5),
        }
        self._wp2_enabled: bool = True

        # ── Build UI ──────────────────────────────────────────────────────────
        self._init_window()
        self._build_left_panel()
        self._build_plots()
        self._connect_signals()

        # Initialise physics with the default slider values.
        self._reset()

        # ── Animation timer ───────────────────────────────────────────────────
        self._timer = QtCore.QTimer(self)
        self._timer.timeout.connect(self._update_loop)
        self._timer.start(TIMER_MS)

        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose)

    # ══════════════════════════════════════════════════════════════════════════
    # UI CONSTRUCTION
    # ══════════════════════════════════════════════════════════════════════════

    def _init_window(self) -> None:
        self.setWindowTitle("Advanced 2D GPE Solver  |  Multiple Potentials")
        self.resize(WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setStyleSheet("background-color: #f5f5f5; color: #222;")

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        self._root = QtWidgets.QHBoxLayout(central)
        self._root.setContentsMargins(0, 0, 0, 0)

    def _build_left_panel(self) -> None:
        panel = QtWidgets.QVBoxLayout()
        panel.setContentsMargins(15, 15, 15, 15)
        panel.setSpacing(12)

        # Control buttons
        self._btn_start = _btn("▶  Start",    "#4CAF50")
        self._btn_pause = _btn("⏸  Pause",    "#ff9800")
        self._btn_reset = _btn("↺  Reset",    "#2196F3")
        self._btn_gif   = _btn("⏺  Save GIF", "#9c27b0")

        row = QtWidgets.QHBoxLayout()
        for b in (self._btn_start, self._btn_pause, self._btn_reset):
            row.addWidget(b)
        panel.addLayout(row)
        panel.addWidget(self._btn_gif)

        # Tabs
        tabs = QtWidgets.QTabWidget()
        tabs.setStyleSheet(_TAB_CSS)
        tabs.addTab(self._build_system_tab(),     "System")
        tabs.addTab(self._build_wavepacket_tab(), "Wavepackets")
        panel.addWidget(tabs)

        self._status = QtWidgets.QLabel("Status: Ready")
        self._status.setStyleSheet(
            "color: #008000; font-weight: bold; font-size: 11px;"
        )
        self._status.setWordWrap(True)
        panel.addWidget(self._status)

        self._root.addLayout(panel, 1)

    # ── System tab ────────────────────────────────────────────────────────────

    def _build_system_tab(self) -> QtWidgets.QWidget:
        tab = QtWidgets.QWidget()
        lay = QtWidgets.QVBoxLayout(tab)
        lay.setSpacing(10)

        lay.addWidget(QtWidgets.QLabel("Evolution Mode:"))
        self._mode_combo = QtWidgets.QComboBox()
        self._mode_combo.addItems(["Pure GPE", "Thermal SGPE"])
        self._mode_combo.setStyleSheet(_COMBO_CSS)
        lay.addWidget(self._mode_combo)

        # Temperature slider — disabled until Thermal SGPE is selected.
        self._temp_sl, self._temp_lbl = _labeled_slider(
            lay, "Temperature (T):", 0, 120, 0,
            fmt=lambda v: f"T = {v}",
        )
        self._temp_sl.setEnabled(False)

        lay.addWidget(QtWidgets.QLabel("Potential Type:"))
        self._pot_combo = QtWidgets.QComboBox()
        self._pot_combo.addItems(POTENTIAL_TYPES)
        self._pot_combo.setStyleSheet(_COMBO_CSS)
        lay.addWidget(self._pot_combo)

        self._v0_sl, _ = _labeled_slider(
            lay, "Strength (V₀):", 0, V0_MAX, 100,
            fmt=lambda v: f"V₀ = {v}",
        )
        self._w_sl, _ = _labeled_slider(
            lay, "Width (w):", 5, 100, 40,
            fmt=lambda v: f"w = {v / W_SLIDER_SCALE:.1f}",
        )
        self._g_sl, _ = _labeled_slider(
            lay, "BEC interaction (g):", -100, 100, int(INTERACTION),
            fmt=lambda v: f"g = {v:.1f}",
        )

        lay.addStretch()
        return tab

    # ── Wavepacket tab ────────────────────────────────────────────────────────

    def _build_wavepacket_tab(self) -> QtWidgets.QWidget:
        tab = QtWidgets.QWidget()
        lay = QtWidgets.QVBoxLayout(tab)
        lay.setSpacing(8)

        self._wp2_check = QtWidgets.QCheckBox("Enable Second Wavepacket")
        self._wp2_check.setChecked(self._wp2_enabled)
        lay.addWidget(self._wp2_check)

        lay.addWidget(self._build_packet_group('wp1', 'Wavepacket 1'))
        lay.addWidget(self._build_packet_group('wp2', 'Wavepacket 2'))
        lay.addStretch()
        return tab

    def _build_packet_group(self, key: str, title: str) -> QtWidgets.QGroupBox:
        """Build a GroupBox with X, Y, Vx, Vy, Width sliders for one packet."""
        group = QtWidgets.QGroupBox(title)
        group.setStyleSheet(_GROUP_CSS)
        g_lay = QtWidgets.QVBoxLayout(group)

        params = [
            ('x',  'X',    -15.0, 15.0, 100.0),
            ('y',  'Y',    -15.0, 15.0, 100.0),
            ('vx', 'Vx',   -30.0, 30.0, 100.0),
            ('vy', 'Vy',   -30.0, 30.0, 100.0),
            ('w',  'Width',  0.5,  8.0, 100.0),
        ]
        for attr, disp, lo, hi, div in params:
            val = self._wp[key][attr]
            lbl = QtWidgets.QLabel(f"{disp} = {val:.2f}")

            sl = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
            sl.setRange(int(lo * div), int(hi * div))
            sl.setValue(int(val * div))
            sl.setStyleSheet(_SLIDER_SM_CSS)

            # Default-argument capture avoids the classic loop-closure trap.
            def _cb(v, k=key, a=attr, d=disp, label=lbl, dv=div):
                self._wp[k][a] = v / dv
                label.setText(f"{d} = {v / dv:.2f}")

            sl.valueChanged.connect(_cb)
            g_lay.addWidget(lbl)
            g_lay.addWidget(sl)

        return group

    # ── Plot panel ────────────────────────────────────────────────────────────

    def _build_plots(self) -> None:
        glw = pg.GraphicsLayoutWidget()
        glw.setBackground('#FFFFFF')
        glw.ci.layout.setContentsMargins(15, 15, 15, 15)
        glw.ci.layout.setSpacing(30)
        self._root.addWidget(glw, 4)

        axis_pen  = pg.mkPen(color='#555555', width=1.2)
        tick_font = QtGui.QFont('Segoe UI', 10)
        tick_font.setStyleHint(QtGui.QFont.StyleHint.SansSerif)

        def _mk_plot(col: int, title: str) -> pg.PlotItem:
            p = glw.addPlot(row=0, col=col)
            p.setTitle(title, color='#222222', size='14pt', bold=True)
            p.setAspectLocked(True)
            for name in ('left', 'bottom'):
                ax = p.getAxis(name)
                ax.setPen(axis_pen)
                ax.setTextPen(axis_pen)
                ax.setStyle(tickFont=tick_font, tickLength=6)
            p.setLabel('left',   'y', color='#333', size='12pt', bold=True)
            p.setLabel('bottom', 'x', color='#333', size='12pt', bold=True)
            p.showGrid(x=True, y=True, alpha=0.2)
            return p

        p1 = _mk_plot(0, 'Density |ψ|²')
        p2 = _mk_plot(1, 'Phase arg(ψ)')

        self._img_dens  = pg.ImageItem()
        self._img_phase = pg.ImageItem()
        p1.addItem(self._img_dens)
        p2.addItem(self._img_phase)

        # Density — inferno
        cmap_dens = pg.colormap.get('inferno')
        self._img_dens.setLookupTable(cmap_dens.getLookupTable())
        try:
            pg.ColorBarItem(interactive=False, cmap=cmap_dens).setImageItem(
                self._img_dens, insert_in=p1
            )
        except Exception:
            pass

        # Phase — prefer a cyclic colormap; fall back gracefully.
        cmap_phase = pg.colormap.get('viridis')   # safe default
        for name in ('cet_c1', 'hsv'):
            try:
                cmap_phase = pg.colormap.get(name)
                break
            except Exception:
                continue

        self._img_phase.setLookupTable(cmap_phase.getLookupTable())
        try:
            pg.ColorBarItem(interactive=False, cmap=cmap_phase).setImageItem(
                self._img_phase, insert_in=p2
            )
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════════════════
    # SIGNAL WIRING
    # ══════════════════════════════════════════════════════════════════════════

    def _connect_signals(self) -> None:
        # Simulation control buttons.
        self._btn_start.clicked.connect(lambda: setattr(self, 'is_running', True))
        self._btn_pause.clicked.connect(lambda: setattr(self, 'is_running', False))
        self._btn_reset.clicked.connect(self._reset)
        self._btn_gif.clicked.connect(self._on_gif_clicked)

        # Mark V as stale when any potential slider changes.
        for widget in (self._pot_combo, self._v0_sl, self._w_sl):
            sig = (widget.currentTextChanged
                   if isinstance(widget, QtWidgets.QComboBox)
                   else widget.valueChanged)
            sig.connect(lambda *_: setattr(self, '_potential_dirty', True))

        # Mode and temperature.
        self._mode_combo.currentTextChanged.connect(self._on_mode_changed)
        self._temp_sl.valueChanged.connect(
            lambda v: setattr(self.physics, 'temperature', float(v))
        )

        # BEC coupling constant.
        self._g_sl.valueChanged.connect(
            lambda v: setattr(self.physics, 'g', float(v))
        )

        # Second wavepacket toggle.
        self._wp2_check.stateChanged.connect(
            lambda s: setattr(self, '_wp2_enabled', bool(s))
        )

        # GIF save-finished — runs on the main thread via Qt signal delivery.
        self.recorder.save_finished.connect(self._on_gif_saved)

    # ══════════════════════════════════════════════════════════════════════════
    # SIMULATION CONTROL
    # ══════════════════════════════════════════════════════════════════════════

    def _reset(self) -> None:
        """Rebuild ψ from the current slider values."""
        V   = self._build_potential()
        wp2 = self._wp['wp2'] if self._wp2_enabled else None
        self.physics.initialize_wavefunction(V, self._wp['wp1'], wp2)
        self._potential_dirty = False
        self._status.setText("Status: Ready")

    def _build_potential(self) -> cp.ndarray:
        """Read sliders and compute V(x, y) on the GPU."""
        return self.pot_builder.build(
            self._pot_combo.currentText(),
            float(self._v0_sl.value()),
            self._w_sl.value() / W_SLIDER_SCALE,
        )

    def _on_mode_changed(self, mode: str) -> None:
        is_sgpe = (mode == "Thermal SGPE")
        self.physics.thermal_mode = is_sgpe
        self.physics.gamma        = 0.05 if is_sgpe else 0.0
        self._temp_sl.setEnabled(is_sgpe)
        if not is_sgpe:
            self.physics.temperature = 0.0
            # Reset the slider (which will also update its label via the
            # valueChanged connection in _labeled_slider).
            self._temp_sl.setValue(0)

    # ══════════════════════════════════════════════════════════════════════════
    # ANIMATION LOOP
    # ══════════════════════════════════════════════════════════════════════════

    def _update_loop(self) -> None:
        """Called every TIMER_MS ms.  Steps physics and refreshes the display."""
        if not self.is_running:
            return

        try:
            if self._potential_dirty:
                self.physics.set_potential(self._build_potential())
                self._potential_dirty = False

            self.physics.step()
            dens, phase, ch = self.physics.get_display_arrays()

            self._img_dens.setImage( dens,  autoLevels=False, levels=(0.0, ch))
            self._img_phase.setImage(phase, autoLevels=False, levels=(-np.pi, np.pi))

            if self.recorder.is_recording:
                done = self.recorder.try_add_frame(dens, phase, ch)
                cur, total = self.recorder.frame_progress
                self._status.setText(
                    f"● REC  {cur} / {total} frames" if not done
                    else "Recording complete — rendering…"
                )
                if done:
                    self.recorder.begin_save(self, self._pending_gif_path)
            else:
                self._status.setText("Status: Running")

        except Exception as exc:
            self._status.setText(f"Error: {exc}")
            self.is_running = False

    # ══════════════════════════════════════════════════════════════════════════
    # GIF RECORDING
    # ══════════════════════════════════════════════════════════════════════════

    def _on_gif_clicked(self) -> None:
        """Duration dialog → file dialog → start recording."""
        dlg = RecordDialog(self)
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return

        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save GIF as…", "gpe_simulation.gif", "Animated GIF (*.gif)"
        )
        if not path:
            return

        self._pending_gif_path = path
        self.recorder.start(dlg.duration, self._sim_params())

        self.is_running = True          # ensure physics is producing frames
        self._btn_gif.setText("● Recording…")
        self._btn_gif.setEnabled(False)

    def _on_gif_saved(self) -> None:
        """Called on the main thread once the GIF file is written."""
        self._btn_gif.setText("⏺  Save GIF")
        self._btn_gif.setEnabled(True)
        self._status.setText(
            "Status: Running" if self.is_running else "Status: Ready"
        )

    def _sim_params(self) -> dict:
        return {
            'potential': self._pot_combo.currentText(),
            'g'        : self.physics.g,
            'N'        : self.physics.N,
            'dt'       : self.physics.dt,
        }

    # ══════════════════════════════════════════════════════════════════════════
    # CLEANUP
    # ══════════════════════════════════════════════════════════════════════════

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        self.is_running = False
        self._timer.stop()
        self.physics.free()
        event.accept()


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == '__main__':
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)
    win = GPEWindow()
    win.show()
    sys.exit(app.exec())
