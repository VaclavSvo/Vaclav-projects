"""
physics.py — GPU split-step Fourier GPE integrator.

All CuPy arrays live here.  The rest of the application only sees NumPy
arrays (returned by get_display_arrays) and plain Python scalars.

Split-step (Strang) scheme — second-order accurate in time:
    ψ ← exp(−i Δt/2 · [V + g|ψ|²]) · ψ           (half potential step)
    ψ ← ifft( exp(−i Δt/2 · k²) · fft(ψ) )        (full kinetic step)
    ψ ← exp(−i Δt/2 · [V + g|ψ|²]) · ψ           (half potential step)

Adjacent half-potential steps from consecutive full time-steps are merged
into one full potential step, so the cost per interior step is:
    1 FFT + 1 iFFT + 2 potential phases  (not 3).

For the Stochastic GPE (SGPE) the replacement i → i + γ introduces damping,
and filtered Gaussian noise is injected in Fourier space to model a thermal
reservoir at temperature T.
"""
from __future__ import annotations

import cupy as cp
import numpy as np

from config import (
    GRID_SIZE, DOMAIN_SIZE, TIME_STEP,
    STEPS_PER_FRAME, INTERACTION, DISPLAY_MAX_PX,
)


class GPEPhysics:
    """
    Manages all GPU arrays and runs the time-integration loop.

    Public interface
    ----------------
    initialize_wavefunction(V, wp1, wp2=None)
    set_potential(V)
    step()
    get_display_arrays() → (dens_np, phase_np, contrast_high)
    free()
    """

    def __init__(
        self,
        N              : int   = GRID_SIZE,
        L              : float = DOMAIN_SIZE,
        dt             : float = TIME_STEP,
        steps_per_frame: int   = STEPS_PER_FRAME,
        g              : float = INTERACTION,
    ) -> None:
        self.N               = N
        self.L               = L
        self.dt              = dt
        self.steps_per_frame = steps_per_frame
        self.g               = g

        # SGPE parameters — toggled from the UI.
        self.thermal_mode = False
        self.gamma        = 0.0
        self.temperature  = 0.0

        self.psi      : cp.ndarray | None = None
        self.V        : cp.ndarray | None = None
        self.max_dens : float             = 1.0

        # Integer stride that sub-samples the grid for display.
        self._stride = max(1, N // DISPLAY_MAX_PX)

        self._build_grids()

    # ── Grid initialisation ───────────────────────────────────────────────────

    def _build_grids(self) -> None:
        x = cp.linspace(-self.L / 2, self.L / 2, self.N, dtype=cp.float32)
        self.Y, self.X = cp.meshgrid(x, x, indexing='ij')
        self.dx = float(x[1] - x[0])

        # k-space frequencies in rad / unit-length.
        kx = cp.fft.fftfreq(self.N, d=self.dx).astype(cp.float32) * (2.0 * np.pi)
        Ky, Kx = cp.meshgrid(kx, kx, indexing='ij')
        self.K_sq = Kx**2 + Ky**2

        # Pre-computed fixed propagators (do not depend on V or ψ).
        self.exp_K        = cp.exp(-1j * 0.5 * self.dt * self.K_sq).astype(cp.complex64)
        self.noise_filter = cp.exp(-0.04  * self.K_sq).astype(cp.complex64)

    # ── Wavefunction initialisation ───────────────────────────────────────────

    def initialize_wavefunction(
        self,
        V  : cp.ndarray,
        wp1: dict,
        wp2: dict | None = None,
    ) -> None:
        """
        Build ψ from one or two Gaussian wavepackets, then normalise to unit L².

        Parameters
        ----------
        V   : float32 GPU potential array (already computed by PotentialBuilder).
        wp1 : dict with keys x, y, vx, vy, w — centre, velocity, and width.
        wp2 : optional second wavepacket dict.
        """
        self.V = V

        def _packet(wp: dict) -> cp.ndarray:
            r2 = (self.X - wp['x'])**2 + (self.Y - wp['y'])**2
            return (
                cp.exp(-0.5 * r2 / wp['w']**2)
                * cp.exp(1j * (wp['vx'] * self.X + wp['vy'] * self.Y))
            )

        psi = _packet(wp1) + (_packet(wp2) if wp2 is not None else 0.0)
        self.psi = psi.astype(cp.complex64)
        self._normalise()
        self.max_dens = float(cp.max(self._density(self.psi))) * 1.5

    def set_potential(self, V: cp.ndarray) -> None:
        self.V = V

    def _normalise(self) -> None:
        norm = float(cp.sqrt(cp.sum(self._density(self.psi)) * self.dx**2))
        if norm > 0.0:
            self.psi /= norm

    # ── Time-stepping ─────────────────────────────────────────────────────────

    @staticmethod
    def _density(psi: cp.ndarray) -> cp.ndarray:
        """Return |ψ|² = Re(ψ)² + Im(ψ)² without computing a square root."""
        return psi.real**2 + psi.imag**2

    def step(self) -> None:
        """Advance ψ by steps_per_frame Strang-split sub-steps."""
        psi, V, g, dt = self.psi, self.V, self.g, self.dt

        gamma = self.gamma       if self.thermal_mode else 0.0
        temp  = self.temperature if self.thermal_mode else 0.0

        # Complex-valued time-step constants that encode both rotation and
        # optional damping.  The imaginary part drives GPE evolution; the real
        # part (−γ·Δt) is the SGPE damping.
        c_half = cp.complex64(complex(-0.5 * dt * gamma, -0.5 * dt))
        c_full = cp.complex64(complex(      -dt * gamma,       -dt))

        # Pre-multiply V by the step constants once — V is loop-invariant.
        cV_half = c_half * V   # shape (N, N), complex64
        cV_full = c_full * V

        noise_amp = (0.00015 * temp * self.N
                     if (gamma > 0.0 and temp > 0.0) else 0.0)
        last = self.steps_per_frame - 1

        for i in range(self.steps_per_frame):
            # Half potential step: exp(c_half · (V + g·|ψ|²))
            dens = self._density(psi)
            psi *= cp.exp(cV_half + c_half * g * dens)

            # Full kinetic step in Fourier space.
            psi_k = cp.fft.fft2(psi)
            if noise_amp:
                noise  = (cp.random.normal(size=psi_k.shape, dtype=cp.float32)
                          + 1j * cp.random.normal(size=psi_k.shape, dtype=cp.float32))
                psi_k += noise_amp * noise * self.noise_filter
            psi_k *= self.exp_K
            psi    = cp.fft.ifft2(psi_k)

            # Half potential step for the final sub-step; full step for
            # interior sub-steps (merges the trailing half of step i with the
            # leading half of step i+1, saving one exponential evaluation).
            dens = self._density(psi)
            if i == last:
                psi *= cp.exp(cV_half + c_half * g * dens)
            else:
                psi *= cp.exp(cV_full + c_full * g * dens)

        self.psi = psi

    # ── Display extraction ────────────────────────────────────────────────────

    def get_display_arrays(self) -> tuple[np.ndarray, np.ndarray, float]:
        """
        Sub-sample ψ and transfer density + phase to the CPU in one PCIe call.

        Packing real and imaginary parts into a single array halves the number
        of GPU→CPU transfers compared to two separate .get() calls.

        Returns
        -------
        dens_np  : float32 ndarray, shape (N_d, N_d).
        phase_np : float32 ndarray, shape (N_d, N_d); NaN below density threshold.
        ch       : float — upper bound for the density colour scale.
        """
        s     = self._stride
        psi_d = self.psi[::s, ::s]          # sub-sampled view, still on GPU

        # Single GPU→CPU transfer: pack [Re, Im] into one (2, N_d, N_d) array.
        ri = cp.stack([psi_d.real, psi_d.imag]).get()  # numpy float32

        dens_np  = (ri[0]**2 + ri[1]**2).T             # |ψ|², transposed for pyqtgraph
        phase_np = np.arctan2(ri[1], ri[0]).T           # arg(ψ)

        # Exponential moving average keeps the colour scale stable.
        cur_max       = float(dens_np.max()) if dens_np.size else 1.0
        self.max_dens = 0.90 * self.max_dens + 0.10 * cur_max

        # Suppress noisy phase in near-vacuum regions.
        phase_np[dens_np < 0.005 * self.max_dens] = np.nan

        return dens_np, phase_np, max(1e-7, self.max_dens * 1.10)

    # ── Resource management ───────────────────────────────────────────────────

    def free(self) -> None:
        """Release GPU arrays and flush the CuPy memory pool."""
        for attr in ('psi', 'V', 'X', 'Y', 'K_sq', 'exp_K', 'noise_filter'):
            if hasattr(self, attr):
                delattr(self, attr)
        try:
            cp.get_default_memory_pool().free_all_blocks()
        except Exception:
            pass
